<?php
namespace SwagTutorialTheme;

use Shopware\Components\Plugin;

class SwagTutorialTheme extends Plugin
{
}
