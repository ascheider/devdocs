

Ext.define('Shopware.apps.SwagProductListing.view.detail.Product', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'SwagProductListing'
        };
    }
});