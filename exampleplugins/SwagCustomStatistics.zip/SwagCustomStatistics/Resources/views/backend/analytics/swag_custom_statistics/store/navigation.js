// {block name="backend/analytics/store/navigation/items"}
// {$smarty.block.parent}
{
    id: 'voucher',
    text: 'Gutscheine',
    store: 'analytics-store-voucher',
    iconCls: 'sprite-ticket',
    comparable: true,
    leaf: true,
    multiShop: true
},
// {/block}
