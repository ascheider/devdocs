
Ext.define('Shopware.apps.SwagProductAssoc.view.detail.Attribute', {
    extend: 'Shopware.model.Container',
//    padding: 20,

    configure: function() {
        return {
            fieldAlias: 'attribute'
        }
    }
});