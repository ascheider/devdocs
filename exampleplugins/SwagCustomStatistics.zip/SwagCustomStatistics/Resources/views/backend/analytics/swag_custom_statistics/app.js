// {block name="backend/analytics/application"}
// {$smarty.block.parent}

// {include file="backend/analytics/swag_custom_statistics/store/navigation/voucher.js"}
// {include file="backend/analytics/swag_custom_statistics/view/chart/voucher.js"}
// {include file="backend/analytics/swag_custom_statistics/view/table/voucher.js"}

// {/block}
