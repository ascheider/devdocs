//

Ext.define('Shopware.apps.SwagProductBasic.view.detail.Product', {
    extend: 'Shopware.model.Container',
    padding: 20,

    configure: function() {
        return {
            controller: 'SwagProductBasic'
        };
    }
});